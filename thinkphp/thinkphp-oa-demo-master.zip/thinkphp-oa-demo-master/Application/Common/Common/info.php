<?php

function getInfo() {
    phpinfo();
}

