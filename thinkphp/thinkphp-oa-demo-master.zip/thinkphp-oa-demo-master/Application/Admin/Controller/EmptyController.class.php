<?php
namespace Admin\Controller;
use Think\Controller;

/**
*
*/
class EmptyController extends Controller
{
    // public function _empty() {
        // echo "访问的页面不存在";
        // $this -> display('Empty/error');
    // }
}

 ?>
