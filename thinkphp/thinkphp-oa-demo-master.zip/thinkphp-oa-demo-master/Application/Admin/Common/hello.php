<?php
function sayHello($who) {
    echo 'hello' . $who;
}


 ?>
