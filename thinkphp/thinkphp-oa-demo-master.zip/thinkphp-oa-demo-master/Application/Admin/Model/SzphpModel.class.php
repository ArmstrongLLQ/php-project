<?php
namespace Admin\Model;
//引入父类元素
use Think\Model;
//声明类并继承父类
class SzphpModel extends Model {
    protected $trueTableName = 'szphp';
}



 ?>
