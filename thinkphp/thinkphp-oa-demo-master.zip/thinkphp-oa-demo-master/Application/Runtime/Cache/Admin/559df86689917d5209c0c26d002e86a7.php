<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
$a = <?php echo ($a); ?> <br>
$b = <?php echo ($b); ?>
</body>
</html>